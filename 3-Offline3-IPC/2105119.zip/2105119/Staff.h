class Staff {
    public:
        int staffId;
        int reviewingInterval;
    public:
        Staff(int id, int reviewingInterval) {
            this->staffId = id;
            this->reviewingInterval = reviewingInterval;
        }
    };